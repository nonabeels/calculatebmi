package com.example.firsttry;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity
        implements View.OnClickListener {
    Button calculate, viewSaved, about;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initializeViews();
        calculate.setOnClickListener(this);
        viewSaved.setOnClickListener(this);
        about.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent i = new Intent();
        switch (v.getId()) {
            case R.id.calculateBtn:
                i = new Intent(getApplicationContext(), CalculateActivity.class);
                break;
            case R.id.savedBtn:
                i = new Intent(getApplicationContext(), ListDataActivity.class);
                break;
            case R.id.abtBtn:
                i = new Intent(getApplicationContext(), About.class);
                break;
        }
        startActivity(i);
    }

    private void initializeViews() {
        calculate = findViewById(R.id.calculateBtn);
        viewSaved = findViewById(R.id.savedBtn);
        about = findViewById(R.id.abtBtn);
    }
}
